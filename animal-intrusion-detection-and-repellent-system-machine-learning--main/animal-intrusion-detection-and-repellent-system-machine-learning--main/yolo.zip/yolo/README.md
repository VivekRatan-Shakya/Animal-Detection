1. Create Conda env
2. Activate env
3. run this commond in terminal   pip install -r requirements.txt
4. run this commond  python run.py



venv\Scripts\activate   python run.py



now your webcam will open 

close webcam press q

